package com.example.material_design3_practice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
